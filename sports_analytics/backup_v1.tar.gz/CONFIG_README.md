# Configuration Guide

2. Run `python3 scripts/update_data.py` to regenerate

If you change `CURRENT_WEEK` **forwards** (normal progression):
- No cache deletion needed
- New historical predictions are automatically cached
