

let currentWeekSpec = 23; // Default placeholder, will be updated by API call to server
let currentView = 'standings';
let dashboardData = null;
let statsChart = null;
let tablePointsChart = null;
let waiversData = []; // Store waivers locally for sorting

// --- Initialization ---

document.addEventListener('DOMContentLoaded', async () => {
    await initDashboard();

    // Periodically refresh if needed, for now just load once
});

async function initDashboard() {
    try {
        const response = await fetch('/api/init');
        const data = await response.json();
        dashboardData = data;

        currentWeekSpec = data.current_week;
        document.getElementById('current-week-display').textContent = currentWeekSpec;
        document.getElementById('pred-week').textContent = currentWeekSpec;

        // Render Standings
        renderStandings('table-standard', data.standings.standard);
        renderStandings('table-median', data.standings.median);
        renderStandings('table-optimal', data.standings.optimal || []); // Handle missing optimal
        renderStandings('table-optimal', data.standings.optimal || []); // Handle missing optimal
        renderChampionsLeague(data.champions_league || []);
        renderCupBracket(data.cup_bracket || {});

        // Setup Week Selector
        const weeks = data.weeks.sort((a, b) => b - a);
        const selector = document.getElementById('week-selector');
        selector.innerHTML = weeks.map(w => `<option value="${w}">Week ${w}</option>`).join('');
        selector.value = currentWeekSpec; // Default to current

        // Load Initial Matchups
        loadMatchups(currentWeekSpec);

    } catch (e) {
        console.error("Initialization failed:", e);
    }
}

// --- Navigation ---

function switchTab(tabName) {
    currentView = tabName;

    // Buttons
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    document.getElementById(`tab-${tabName}`).classList.add('active');

    // View Sections
    document.querySelectorAll('.view-section').forEach(el => el.classList.add('hidden'));
    document.querySelectorAll('.view-section').forEach(el => el.classList.remove('active'));

    const activeView = document.getElementById(`view-${tabName}`);
    activeView.classList.remove('hidden');
    activeView.classList.add('active');

    if (tabName === 'stats' && dashboardData && dashboardData.advanced_stats) {
        renderStats(dashboardData.advanced_stats);
    }
    if (tabName === 'stats' && dashboardData && dashboardData.advanced_stats) {
        renderStats(dashboardData.advanced_stats);
    }

    if (tabName === 'waivers') {
        loadWaivers();
    }
}

function renderStats(stats) {
    // 1. Superlatives
    const supGrid = document.getElementById('stats-superlatives');
    if (stats.superlatives) {
        const sup = stats.superlatives;
        const cards = [
            { label: 'Form King', ...sup.form_king, color: 'text-yellow-400' },
            { label: 'Most Consistent', ...sup.most_consistent, color: 'text-blue-400' },
            { label: 'Wildcard', ...sup.wildcard, color: 'text-purple-400' },
            { label: 'Unluckiest', ...sup.unluckiest, color: 'text-red-400' },
            { label: 'Luckiest', ...sup.luckiest, color: 'text-green-400' },
        ];

        supGrid.innerHTML = cards.map(c => `
             <div class="glass-panel p-4 rounded-xl text-center">
                 <div class="text-xs text-gray-500 uppercase font-bold mb-1">${c.label}</div>
                 <div class="text-lg font-bold text-white mb-1">${c.team}</div>
                 <div class="text-2xl font-mono ${c.color}">${c.val}</div>
                 <div class="text-xs text-gray-500 mt-2 italic">${c.desc}</div>
             </div>
        `).join('');
    }

    // 2. Form Table
    const formBody = document.getElementById('stats-form-table');
    const sortedStats = [...stats.team_stats].sort((a, b) => b.last_5_avg - a.last_5_avg);

    formBody.innerHTML = sortedStats.map(t => {
        const formHtml = t.form.split('').map(r => {
            let col = 'text-gray-500';
            if (r === 'W') col = 'text-green-400';
            if (r === 'L') col = 'text-red-400';
            if (r === 'D') col = 'text-yellow-400';
            return `<span class="${col} font-bold mr-1">${r}</span>`;
        }).join('');

        return `
         <tr class="border-b border-gray-800 last:border-0 hover:bg-gray-800/30">
            <td class="py-2 font-medium">${t.team}</td>
            <td class="py-2 text-center font-mono text-white">${t.last_5_avg.toFixed(1)}</td>
            <td class="py-2 text-right">${formHtml}</td>
         </tr>
       `;
    }).join('');

    // 3. Charts
    if (!stats.team_stats || stats.team_stats.length === 0) return;

    // Generate consistent colors for all teams
    const teamColors = stats.team_stats.map((t, i) => {
        const hue = (i * 137.508) % 360;
        return `hsl(${hue}, 70%, 50%)`;
    });

    const labels = stats.team_stats[0].weekly_trend.map(wt => `W${wt.week}`);

    // 3a. Fantasy Points Chart
    const ctx1 = document.getElementById('seasonTrendChart').getContext('2d');
    if (statsChart) statsChart.destroy();

    const fantasyDatasets = stats.team_stats.map((t, i) => ({
        label: t.team,
        data: t.weekly_trend.map(wt => wt.score),
        borderColor: teamColors[i],
        backgroundColor: teamColors[i],
        borderWidth: 2,
        tension: 0.3,
        pointRadius: 0,
        pointHoverRadius: 4
    }));

    statsChart = new Chart(ctx1, {
        type: 'line',
        data: {
            labels: labels,
            datasets: fantasyDatasets
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: {
                mode: 'index',
                intersect: false,
            },
            plugins: {
                legend: {
                    display: false,  // Hide legend - shown on bottom chart only
                    position: 'bottom',
                    labels: {
                        color: '#9ca3af',
                        font: { size: 10 },
                        usePointStyle: true,
                        padding: 10
                    }
                },
                tooltip: {
                    mode: 'index',
                    intersect: false
                }
            },
            scales: {
                y: {
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    ticks: { color: '#9ca3af' }
                },
                x: {
                    grid: { display: false },
                    ticks: { color: '#9ca3af' }
                }
            }
        }
    });

    // 3b. Table Points Chart
    const ctx2 = document.getElementById('tablePointsChart').getContext('2d');
    if (tablePointsChart) tablePointsChart.destroy();

    const tableDatasets = stats.team_stats.map((t, i) => ({
        label: t.team,
        data: t.weekly_trend.map(wt => wt.table_points || 0),
        borderColor: teamColors[i],
        backgroundColor: teamColors[i],
        borderWidth: 2,
        tension: 0.3,
        pointRadius: 0,
        pointHoverRadius: 4
    }));

    tablePointsChart = new Chart(ctx2, {
        type: 'line',
        data: {
            labels: labels,
            datasets: tableDatasets
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: {
                mode: 'index',
                intersect: false,
            },
            plugins: {
                legend: {
                    display: true,
                    position: 'bottom',
                    labels: {
                        color: '#9ca3af',
                        font: { size: 10 },
                        usePointStyle: true,
                        padding: 10
                    }
                },
                tooltip: {
                    mode: 'index',
                    intersect: false
                }
            },
            scales: {
                y: {
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    ticks: { color: '#9ca3af', stepSize: 3 }
                },
                x: {
                    grid: { display: false },
                    ticks: { color: '#9ca3af' }
                }
            }
        }
    });

    // 4. Weekly Extremes
    const extBody = document.getElementById('stats-extremes-table');
    if (stats.weekly_extremes) {
        extBody.innerHTML = stats.weekly_extremes.map(w => `
            <tr class="border-b border-gray-800 last:border-0 hover:bg-gray-800/30">
                <td class="py-2 font-mono text-gray-500">Week ${w.week}</td>
                <td class="py-2 font-medium text-green-300">${w.high_team}</td>
                <td class="py-2 text-right font-mono font-bold">${w.high_score.toFixed(2)}</td>
                <td class="py-2 pl-8 font-medium text-red-300">${w.low_team}</td>
                <td class="py-2 text-right font-mono font-bold">${w.low_score.toFixed(2)}</td>
                
                <td class="py-2 pl-8 font-medium text-blue-300">
                    ${w.best_eff ? w.best_eff.team : '-'} 
                    <span class="text-xs text-gray-500 ml-1">(${w.best_eff ? w.best_eff.pct.toFixed(1) : '0'}%)</span>
                </td>
                <td class="py-2 text-right font-mono text-xs">
                    ${w.best_eff ? w.best_eff.score.toFixed(1) : '0'} / ${w.best_eff ? w.best_eff.opt.toFixed(1) : '0'}
                </td>
                
                <td class="py-2 pl-8 font-medium text-orange-300">
                    ${w.worst_eff ? w.worst_eff.team : '-'}
                    <span class="text-xs text-gray-500 ml-1">(${w.worst_eff ? w.worst_eff.pct.toFixed(1) : '0'}%)</span>
                </td>
                <td class="py-2 text-right font-mono text-xs">
                    ${w.worst_eff ? w.worst_eff.score.toFixed(1) : '0'} / ${w.worst_eff ? w.worst_eff.opt.toFixed(1) : '0'}
                </td>
            </tr>
        `).join('');
    }

}

// --- Renderers ---

function renderStandings(tableId, data) {
    const tbody = document.querySelector(`#${tableId} tbody`);
    if (!data || data.length === 0) {
        if (tableId !== 'table-optimal') { // Optimal has its own placeholder
            tbody.innerHTML = '<tr><td colspan="5" class="py-4 text-center text-gray-500">No data available</td></tr>';
        }
        return;
    }

    tbody.innerHTML = data.map(team => `
        <tr class="hover:bg-gray-800/50 transition-colors">
            <td class="font-bold pl-2 ${getRankColor(team.rank, data.length)}">${team.rank}</td>
            <td class="font-medium">${team.team}</td>
            <td class="text-xs text-gray-400 font-mono">${team.record || ''}</td>
            <td class="text-right font-bold text-white">${team.points}</td>
            <td class="text-right text-gray-400 font-mono">${team.fpts_for.toFixed(2)}</td>
        </tr>
    `).join('');
}

function getRankColor(rank, totalTeams) {
    if (rank === 1) return 'text-yellow-400';
    if (rank <= 6) return 'text-blue-400';
    if (rank === totalTeams) return 'text-red-400';
    return 'text-gray-500';
}

function renderChampionsLeague(data) {
    const tbody = document.querySelector('#table-champleague tbody');
    if (!data || data.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="py-4 text-center text-gray-500">No data available</td></tr>';
        return;
    }

    tbody.innerHTML = data.map(team => `
        <tr class="hover:bg-gray-800/50 transition-colors border-b border-gray-800 last:border-0">
            <td class="font-medium py-3 pl-2">
                ${team.team}
                <div class="text-xs text-gray-500">${team.manager}</div>
            </td>
            <td class="text-center text-white font-mono">${team.w}</td>
            <td class="text-center text-gray-400 font-mono">${team.d}</td>
            <td class="text-center text-gray-400 font-mono">${team.l}</td>
            <td class="text-right font-bold text-yellow-400 font-mono text-lg pr-2">${team.pts}</td>
            <td class="text-right text-gray-400 font-mono pr-2">${team.fpts.toFixed(2)}</td>
        </tr>
    `).join('');
}

function renderCupBracket(bracket) {
    const container = document.getElementById('cup-bracket-container');
    if (!bracket || Object.keys(bracket).length === 0) {
        container.innerHTML = '<div class="text-center py-8 text-gray-500">Bracket not available</div>';
        return;
    }

    const rounds = [
        { key: 'qual', label: 'Qualifiers (Wk 9)' },
        { key: 'r1', label: 'Round of 16 (Wk 14)' },
        { key: 'qf', label: 'Quarter Finals (Wk 19)' },
        { key: 'sf', label: 'Semi Finals (Wk 24 & 29)' },
        { key: 'final', label: 'Final (Wk 34)' }
    ];

    let html = '<div class="flex space-x-6 min-w-max pb-4">';

    rounds.forEach(round => {
        const matches = bracket[round.key] || [];

        let matchCards = matches.map(m => {
            const p1 = m.p1 || 'TBD';
            const p2 = m.p2 || 'TBD';
            const s1 = (typeof m.s1 === 'number') ? m.s1.toFixed(0) : '-';
            const s2 = (typeof m.s2 === 'number') ? m.s2.toFixed(0) : '-';

            const p1Class = (m.winner === m.p1 && m.p1) ? 'text-green-400 font-bold' : ((m.p1) ? 'text-gray-200' : 'text-gray-500 italic');
            const p2Class = (m.winner === m.p2 && m.p2) ? 'text-green-400 font-bold' : ((m.p2) ? 'text-gray-200' : 'text-gray-500 italic');

            return `
                <div class="glass-panel p-3 rounded-lg border border-gray-700 w-56 relative flex flex-col justify-center mb-4 last:mb-0">
                    <div class="flex justify-between items-center mb-2">
                        <span class="truncate text-sm ${p1Class} w-32" title="${p1}">${p1}</span>
                        <span class="font-mono text-sm text-gray-400">${s1}</span>
                    </div>
                    <div class="flex justify-between items-center">
                        <span class="truncate text-sm ${p2Class} w-32" title="${p2}">${p2}</span>
                        <span class="font-mono text-sm text-gray-400">${s2}</span>
                    </div>
                    ${m.status === 'Completed' ? '' : `<div class="text-[10px] text-gray-500 mt-2 text-right uppercase">${m.status}</div>`}
                </div>
            `;
        }).join('');

        html += `
            <div class="flex flex-col flex-shrink-0">
                <div class="text-center font-bold text-xs uppercase tracking-wider text-orange-400 mb-4 border-b border-orange-500/30 pb-2">
                    ${round.label}
                </div>
                <div class="flex flex-col justify-center h-full space-y-4">
                    ${matchCards}
                </div>
            </div>
        `;
    });

    html += '</div>';
    container.innerHTML = html;
}

function renderMatchupCardHTML(m, type = 'standard') {
    let borderClass = "glass-panel";
    if (type === 'cl') borderClass = "border border-yellow-500/30 shadow-[0_0_15px_rgba(234,179,8,0.1)]";
    if (type === 'cup') borderClass = "border border-orange-500/30 shadow-[0_0_15px_rgba(249,115,22,0.1)]";

    const containerClass = type !== 'standard' ? 'glass-panel ' + borderClass : 'glass-panel';

    return `
        <div class="${containerClass} p-4 sm:p-6 rounded-xl matchup-card flex justify-between items-center group cursor-pointer hover:bg-white/5 transition-colors" onclick="openMatchup('${m.matchupId}')">
            
            <!-- Home -->
            <div class="flex-1 text-left">
                <div class="font-bold text-sm sm:text-lg ${m.home_score > m.away_score ? 'text-green-400' : 'text-gray-300'}">
                    ${m.home_team}
                </div>
                <div class="text-xl sm:text-2xl font-mono mt-1">${m.home_score.toFixed(2)}</div>
                ${m.home_projected ? `<div class="text-[10px] sm:text-xs text-blue-400 font-mono mt-1">Proj: ${m.home_projected.toFixed(2)}</div>` : ''}
            </div>
            
            <!-- VS -->
            <div class="px-3 sm:px-6 text-gray-600 font-bold text-xs sm:text-sm">VS</div>
            
            <!-- Away -->
            <div class="flex-1 text-right">
                <div class="font-bold text-sm sm:text-lg ${m.away_score > m.home_score ? 'text-green-400' : 'text-gray-300'}">
                    ${m.away_team}
                </div>
                <div class="text-xl sm:text-2xl font-mono mt-1">${m.away_score.toFixed(2)}</div>
                ${m.away_projected ? `<div class="text-[10px] sm:text-xs text-blue-400 font-mono mt-1">Proj: ${m.away_projected.toFixed(2)}</div>` : ''}
            </div>
            
        </div>
    `;
}

async function loadMatchups(week) {
    const grid = document.getElementById('matchups-grid');
    const clSection = document.getElementById('cl-matchups-section');
    const clGrid = document.getElementById('cl-matchups-grid');
    const cupSection = document.getElementById('cup-matchups-section');
    const cupGrid = document.getElementById('cup-matchups-grid');

    grid.innerHTML = '<div class="col-span-full text-center py-12 text-gray-500">Loading matchups...</div>';
    if (clSection) clSection.classList.add('hidden');
    if (cupSection) cupSection.classList.add('hidden');

    try {
        const response = await fetch(`/api/matchups/${week}`);
        const data = await response.json();

        let standard = [];
        let cl = [];
        let cup = [];

        if (Array.isArray(data)) {
            standard = data;
        } else {
            standard = data.standard || [];
            cl = data.champions_league || [];
            cup = data.cup || [];
        }

        // Standard
        if (standard.length === 0) {
            grid.innerHTML = '<div class="col-span-full text-center py-12 text-gray-500">No matchups found for this week.</div>';
        } else {
            grid.innerHTML = standard.map(m => renderMatchupCardHTML(m, 'standard')).join('');
        }

        // Champions League
        if (clSection) {
            if (cl.length > 0) {
                clSection.classList.remove('hidden');
                clGrid.innerHTML = cl.map(m => renderMatchupCardHTML(m, 'cl')).join('');
            } else {
                clSection.classList.add('hidden');
            }
        }

        // Cup
        if (cupSection) {
            if (cup.length > 0) {
                cupSection.classList.remove('hidden');
                cupGrid.innerHTML = cup.map(m => renderMatchupCardHTML(m, 'cup')).join('');
            } else {
                cupSection.classList.add('hidden');
            }
        }

    } catch (e) {
        console.error(e);
        grid.innerHTML = '<div class="col-span-full text-center py-12 text-red-500">Error loading matchups.</div>';
    }
}

// --- Modals ---

// --- Modals ---

let currentMatchupData = null;
let isOptimalView = false;

let currentMatchupWeek = null;

async function openMatchup(matchupId) {
    const modal = document.getElementById('lineup-modal');
    modal.classList.remove('hidden');

    // Reset View State
    isOptimalView = false;
    currentMatchupData = null;

    // Extract week from matchupId
    const parts = matchupId.split('_');
    if (parts[0] === 'CL' || parts[0] === 'CUP') {
        currentMatchupWeek = parseInt(parts[1]);
    } else {
        currentMatchupWeek = parseInt(parts[0]);
    }

    const content = document.getElementById('modal-content');
    content.innerHTML = '<div class="col-span-2 text-center text-gray-400">Loading Lineups from Fantrax...</div>';

    // Update modal header with correct week
    const modalNote = document.getElementById('modal-prediction-note');
    if (modalNote) {
        modalNote.textContent = `Predictions available for Week ${currentMatchupWeek}`;
    }

    try {
        const response = await fetch(`/api/lineup/${matchupId}`);
        currentMatchupData = await response.json();

        renderMatchupView();

    } catch (e) {
        console.error(e);
        content.innerHTML = '<div class="col-span-2 text-center text-red-400">Failed to load lineups.</div>';
    }
}

function renderMatchupView() {
    const content = document.getElementById('modal-content');
    // Always show predictions for all weeks
    const showPreds = true;

    // Controls
    const controlsHtml = `
        <div class="col-span-1 md:col-span-2 flex justify-end mb-4 border-b border-gray-700 pb-2">
            <label class="inline-flex items-center cursor-pointer">
                <input type="checkbox" class="sr-only peer" onchange="toggleOptimal(this)" ${isOptimalView ? 'checked' : ''}>
                <div class="relative w-11 h-6 bg-gray-700 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-800 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                <span class="ms-3 text-sm font-medium text-gray-300">Show Optimal</span>
            </label>
        </div>
    `;

    content.innerHTML = `
        ${controlsHtml}
        ${renderTeamLineup(currentMatchupData.home_team, showPreds, isOptimalView)}
        ${renderTeamLineup(currentMatchupData.away_team, showPreds, isOptimalView)}
    `;
}

function toggleOptimal(checkbox) {
    isOptimalView = checkbox.checked;
    renderMatchupView();
}

function renderTeamLineup(team, showPreds, optimalMode = false) {
    if (!team.roster || team.roster.length === 0) {
        return `
            <div class="glass-panel p-4 rounded-lg bg-gray-800/30">
                <h4 class="text-lg font-bold text-center mb-4 border-b border-gray-700 pb-2">${team.name}</h4>
                <div class="text-gray-500 text-sm italic py-4">Roster data not available yet.</div>
            </div>
        `;
    }

    // Filter valid players (remove null names)
    const validPlayers = team.roster.filter(p => p.name);

    // Determine Starters
    let starterIds = new Set();
    if (optimalMode) {
        starterIds = calculateOptimalStarters(validPlayers);
    } else {
        validPlayers.forEach(p => { if (p.status == '1') starterIds.add(p.player_id); });
    }

    const starters = validPlayers.filter(p => starterIds.has(p.player_id));
    const bench = validPlayers.filter(p => !starterIds.has(p.player_id));

    // Sort starters by position: G, D, M, F
    const posOrder = { 'G': 0, 'D': 1, 'M': 2, 'F': 3 };
    starters.sort((a, b) => {
        const pa = posOrder[a.position] !== undefined ? posOrder[a.position] : 99;
        const pb = posOrder[b.position] !== undefined ? posOrder[b.position] : 99;
        return pa - pb;
    });

    // Calculate Total Score for this lineup view
    const totalScore = starters.reduce((sum, p) => sum + (p.score || 0), 0);

    // Calculate Total Projected
    const totalProj = starters.reduce((sum, p) => {
        return sum + (p.prediction ? (p.prediction.predicted_fpts || 0) : 0);
    }, 0);

    const renderPlayer = (p) => {
        // Build stats string (exclude INJURED from generic loop)
        let statsStr = '';
        let injuryHtml = '';

        if (p.stats) {
            // Handle Injury separately
            if (p.stats.INJURED) {
                const status = p.stats.INJURED;
                if (status === 'Out') {
                    injuryHtml = `<span class="text-red-500 font-bold ml-2">OUT</span>`;
                } else if (status === 'GTD') {
                    injuryHtml = `<span class="text-orange-500 font-bold ml-2">GTD</span>`;
                } else if (status !== 'Available' && status !== 'OK') {
                    // Catch-all for other statuses if any
                    injuryHtml = `<span class="text-red-400 font-bold ml-2">${status}</span>`;
                }
            }

            statsStr = Object.entries(p.stats)
                .filter(([k, v]) => k !== 'INJURED') // Filter out INJURED
                .map(([k, v]) => `<span class="mr-2 text-gray-400">${k}: <span class="text-gray-200">${v}</span></span>`)
                .join('');
        }

        // Score formatting: Always 2 decimals, show even if 0 or negative
        const scoreDisplay = (p.score !== undefined && p.score !== null) ? Number(p.score).toFixed(2) : '0.00';

        return `
        <div class="flex justify-between items-center py-2 border-b border-gray-800 last:border-0">
            <div>
                <div class="flex items-center">
                    <div class="font-medium text-gray-200">${p.name}</div>
                    ${injuryHtml}
                </div>
                <div class="text-xs text-gray-500 mb-1">${p.position} &bull; ${p.team}</div>
                ${statsStr ? `<div class="text-xs">${statsStr}</div>` : ''}
            </div>
            <div class="text-right">
                <div class="font-bold ${p.score < 0 ? 'text-red-400' : 'text-gray-100'} text-lg">${scoreDisplay}</div> 
                ${showPreds && p.prediction && p.prediction.predicted_fpts != null ? `<div class="text-xs text-blue-400 font-bold">Proj: ${Number(p.prediction.predicted_fpts).toFixed(2)}</div>` : ''}
            </div>
        </div>
    `;
    };

    return `
        <div class="glass-panel p-4 rounded-lg bg-gray-800/30 border ${optimalMode ? 'border-blue-500/50' : 'border-transparent'}">
            <h4 class="text-lg font-bold text-center mb-2">${team.name}</h4>
            <div class="text-center mb-4">
                 <span class="text-2xl font-mono ${optimalMode ? 'text-blue-400' : 'text-white'}">${(totalScore || 0).toFixed(2)}</span>
                 ${showPreds ? `<div class="text-sm text-blue-400 font-mono mt-1">Proj: ${(totalProj || 0).toFixed(2)}</div>` : ''}
            </div>
            
            <div class="mb-4">
                <h5 class="text-xs uppercase text-gray-500 font-bold mb-2">Starters</h5>
                <div class="space-y-1">
                    ${starters.map(renderPlayer).join('')}
                </div>
            </div>

            ${bench.length > 0 ? `
            <div>
                <h5 class="text-xs uppercase text-gray-500 font-bold mb-2">Bench</h5>
                <div class="space-y-1 opacity-60 bg-gray-900/20 rounded p-2">
                    ${bench.map(renderPlayer).join('')}
                </div>
            </div>
            ` : ''}
        </div>
    `;
}

function calculateOptimalStarters(allPlayers) {
    // Clone to avoid sorting in place affecting other views
    const players = [...allPlayers];

    // Detect if this is an unplayed week (everyone has 0 points)
    // If so, use predictions instead of actual scores
    // Helper function to get the score to use for optimization
    const getOptimizationScore = (player) => {
        // Hybrid Logic:
        // If player has started/played (is_started=true from server), use ACTUAL score.
        // If player has NOT started, use PROJECTED score.

        if (player.is_started) {
            return player.score || 0;
        } else {
            return player.prediction ? (player.prediction.predicted_fpts || 0) : 0;
        }
    };

    // Helper to get sorted list by position
    const getByPos = (pos) => players
        .filter(p => p.position === pos)
        .sort((a, b) => getOptimizationScore(b) - getOptimizationScore(a));

    // Clone lists because we will shift() from them
    const gks = getByPos('G');
    const defs = getByPos('D');
    const mids = getByPos('M');
    const fwds = getByPos('F');

    const starters = [];

    // 1. Base (1G, 3D, 2M, 1F)
    if (gks.length > 0) starters.push(gks.shift());
    for (let i = 0; i < 3; i++) if (defs.length > 0) starters.push(defs.shift());
    for (let i = 0; i < 2; i++) if (mids.length > 0) starters.push(mids.shift());
    for (let i = 0; i < 1; i++) if (fwds.length > 0) starters.push(fwds.shift());

    // 2. Flex (4 spots)
    for (let i = 0; i < 4; i++) {
        // Candidates from remaining lists that satisfy max constraints
        // Max: 1G (already full), 5D, 5M, 3F.

        const cD = starters.filter(p => p.position === 'D').length;
        const cM = starters.filter(p => p.position === 'M').length;
        const cF = starters.filter(p => p.position === 'F').length;

        let best = null;
        let sourceList = null;
        let bestScore = -9999;

        // Check D
        if (cD < 5 && defs.length > 0) {
            const s = getOptimizationScore(defs[0]);
            if (s > bestScore) { best = defs[0]; sourceList = defs; bestScore = s; }
        }
        // Check M
        if (cM < 5 && mids.length > 0) {
            const s = getOptimizationScore(mids[0]);
            if (s > bestScore) { best = mids[0]; sourceList = mids; bestScore = s; }
        }
        // Check F
        if (cF < 3 && fwds.length > 0) {
            const s = getOptimizationScore(fwds[0]);
            if (s > bestScore) { best = fwds[0]; sourceList = fwds; bestScore = s; }
        }

        if (best) {
            starters.push(best);
            sourceList.shift(); // Remove from pool
        }
    }

    return new Set(starters.map(p => p.player_id));
}

function closeModal() {
    document.getElementById('lineup-modal').classList.add('hidden');
}

// Close on click outside
document.getElementById('lineup-modal').addEventListener('click', (e) => {
    if (e.target.id === 'lineup-modal') closeModal();
});

// --- Chat Functions ---

let chatChart = null; // Store chat chart instance

function clearChat() {
    const messagesDiv = document.getElementById('chat-messages');
    messagesDiv.innerHTML = `
        <div class="text-gray-500 text-sm italic text-center py-8">
            Oi! Ask me something about your rubbish team then!
            <ul class="mt-2 text-left max-w-md mx-auto space-y-1">
                <li>• "Who's the biggest bottler this season?"</li>
                <li>• "Roast the team in last place"</li>
                <li>• "Analyze my waiver options properly, you muppet"</li>
            </ul>
        </div>
    `;

    // Clear any charts
    if (chatChart) {
        chatChart = null;
    }
}

async function sendMessage() {
    const input = document.getElementById('chat-input');
    const message = input.value.trim();

    if (!message) return;

    // Clear input
    input.value = '';

    // Add user message to chat
    addChatMessage('user', message);

    // Show loading
    const loadingId = addChatMessage('assistant', 'Thinking...', true);

    // Disable send button with spinner
    const sendBtn = document.getElementById('send-btn');
    sendBtn.disabled = true;
    sendBtn.innerHTML = `
        <svg class="animate-spin h-5 w-5 text-white mx-auto" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
    `;

    try {
        const response = await fetch('/api/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ message })
        });

        const data = await response.json();

        // Remove loading message
        document.getElementById(loadingId).remove();

        // Render response
        renderChatResponse(data);

    } catch (error) {
        // Remove loading message
        document.getElementById(loadingId).remove();
        addChatMessage('assistant', `Error: ${error.message}`, false, 'error');
    } finally {
        // Re-enable send button
        sendBtn.disabled = false;
        sendBtn.textContent = 'Send';
    }
}

function addChatMessage(role, content, isLoading = false, type = 'text') {
    const container = document.getElementById('chat-messages');

    // Remove welcome message if present (be specific to avoid removing actual messages)
    const welcome = container.querySelector('.text-gray-500.italic.text-center.py-8');
    if (welcome && welcome.parentElement === container) {
        welcome.remove();
    }

    // Use high-res timestamp + random to ensure unique ID even if called multiple times in same ms
    const msgId = `msg-${Date.now()}-${Math.floor(Math.random() * 10000)}`;
    const isUser = role === 'user';

    const msgDiv = document.createElement('div');
    msgDiv.id = msgId;
    msgDiv.className = `flex ${isUser ? 'justify-end' : 'justify-start'}`;

    const bubble = document.createElement('div');
    bubble.className = `max-w-[80%] rounded-lg p-3 ${isUser
        ? 'bg-blue-600 text-white'
        : type === 'error'
            ? 'bg-red-900/50 text-red-200'
            : 'bg-gray-800 text-gray-100'
        }`;

    if (isLoading) {
        bubble.innerHTML = `<div class="flex items-center gap-2">
            <div class="animate-pulse">●</div>
            <div class="animate-pulse" style="animation-delay: 0.2s">●</div>
            <div class="animate-pulse" style="animation-delay: 0.4s">●</div>
        </div>`;
    } else {
        bubble.textContent = content;
    }

    msgDiv.appendChild(bubble);
    container.appendChild(msgDiv);

    // Scroll to bottom
    container.scrollTop = container.scrollHeight;

    return msgId;
}

function renderChatResponse(data) {
    const container = document.getElementById('chat-messages');

    if (!data.success) {
        // Create error message with code if available
        const msgDiv = document.createElement('div');
        msgDiv.className = 'flex justify-start';

        const bubble = document.createElement('div');
        bubble.className = 'max-w-[90%] rounded-lg p-4 bg-red-900/30 border border-red-700 text-gray-100';

        const errorText = document.createElement('div');
        errorText.className = 'text-red-300 mb-2';
        errorText.textContent = data.message || 'An error occurred';
        bubble.appendChild(errorText);

        // Add code viewer if code is present
        if (data.code) {
            const codeToggle = document.createElement('button');
            codeToggle.className = 'mt-3 text-xs text-red-400 hover:text-red-300 underline';
            codeToggle.textContent = 'View Last Attempted Code';

            const codeContainer = document.createElement('div');
            codeContainer.className = 'hidden mt-2 bg-gray-900 rounded p-3 overflow-x-auto';

            const codeBlock = document.createElement('pre');
            codeBlock.className = 'text-xs text-green-400';
            codeBlock.textContent = data.code;
            codeContainer.appendChild(codeBlock);

            codeToggle.onclick = () => {
                if (codeContainer.classList.contains('hidden')) {
                    codeContainer.classList.remove('hidden');
                    codeToggle.textContent = 'Hide Code';
                } else {
                    codeContainer.classList.add('hidden');
                    codeToggle.textContent = 'View Last Attempted Code';
                }
            };

            bubble.appendChild(codeToggle);
            bubble.appendChild(codeContainer);
        }

        msgDiv.appendChild(bubble);
        container.appendChild(msgDiv);
        container.scrollTop = container.scrollHeight;
        return;
    }

    const type = data.type;
    const message = data.message;

    // Debug logging
    console.log('Chat response:', { type, hasData: !!data.data, dataKeys: data.data ? Object.keys(data.data) : [] });

    // Create message container
    const msgDiv = document.createElement('div');
    msgDiv.className = 'flex justify-start';

    const bubble = document.createElement('div');
    // Use full width for plotly charts, otherwise constrain to 90%
    const bubbleWidth = (type === 'plotly' || type === 'text+plot') ? 'w-full' : 'max-w-[90%]';
    bubble.className = `${bubbleWidth} rounded-lg p-4 bg-gray-800 text-gray-100`;

    // Add text message if present (render as markdown)
    if (message) {
        const textDiv = document.createElement('div');
        textDiv.className = 'mb-3 prose prose-invert prose-sm max-w-none';
        textDiv.innerHTML = marked.parse(message);
        bubble.appendChild(textDiv);
    }

    // Handle different response types
    if (type === 'text+plot' && data.data && data.data.html) {
        const plotlyContainer = document.createElement('div');
        plotlyContainer.className = 'mt-3 w-full';
        plotlyContainer.style.minHeight = '400px';

        plotlyContainer.innerHTML = data.data.html;
        bubble.appendChild(plotlyContainer);

        // Execute any inline scripts after a brief delay
        setTimeout(() => {
            const scripts = plotlyContainer.querySelectorAll('script');
            scripts.forEach(script => {
                if (script.textContent && !script.src) {
                    try {
                        const scriptFunc = new Function(script.textContent);
                        scriptFunc();
                    } catch (e) {
                        console.error('Error executing plotly script:', e);
                    }
                }
            });
        }, 100);
    } else if (type === 'text+table' && data.data) {
        // Support both single table and multi-table (dict)
        if (data.data.table && Array.isArray(data.data.table)) {
            // Single table legacy format
            bubble.appendChild(createTableElement(data.data.table));
        } else {
            // Check for multi-table dict (e.g. {'Matchups': [...], 'Standings': [...]})
            Object.keys(data.data).forEach(title => {
                const tableData = data.data[title];
                if (Array.isArray(tableData) && tableData.length > 0) {
                    // Add Title
                    const titleDiv = document.createElement('div');
                    titleDiv.className = 'text-sm font-bold text-gray-400 mt-4 mb-2 uppercase tracking-wider border-b border-gray-700 pb-1';
                    titleDiv.textContent = title.replace(/_/g, ' ');
                    bubble.appendChild(titleDiv);

                    // Add Table
                    bubble.appendChild(createTableElement(tableData));
                }
            });
        }
    } else if (type === 'plotly' && data.data && data.data.html) {
        // Legacy support
        const plotlyContainer = document.createElement('div');
        plotlyContainer.className = 'mt-3 w-full';
        plotlyContainer.style.minHeight = '400px';
        plotlyContainer.innerHTML = data.data.html;
        bubble.appendChild(plotlyContainer);

        setTimeout(() => {
            const scripts = plotlyContainer.querySelectorAll('script');
            scripts.forEach(script => {
                if (script.textContent && !script.src) {
                    try {
                        const scriptFunc = new Function(script.textContent);
                        scriptFunc();
                    } catch (e) {
                        console.error('Error executing plotly script:', e);
                    }
                }
            });
        }, 100);
    } else if (type === 'chart' && data.data) {
        const chartContainer = createChartElement(data.data);
        bubble.appendChild(chartContainer);
    } else if (type === 'table' && data.data) {
        // Support both single table and multi-table
        if (Array.isArray(data.data)) {
            bubble.appendChild(createTableElement(data.data));
        } else {
            // Multi-table dict
            Object.keys(data.data).forEach(title => {
                const tableData = data.data[title];
                if (Array.isArray(tableData) && tableData.length > 0) {
                    const titleDiv = document.createElement('div');
                    titleDiv.className = 'text-sm font-bold text-gray-400 mt-4 mb-2 uppercase tracking-wider border-b border-gray-700 pb-1';
                    titleDiv.textContent = title.replace(/_/g, ' ');
                    bubble.appendChild(titleDiv);
                    bubble.appendChild(createTableElement(tableData));
                }
            });
        }
    }

    // Add collapsible code viewer if code is present
    if (data.code) {
        const codeToggle = document.createElement('button');
        codeToggle.className = 'mt-3 text-xs text-gray-400 hover:text-gray-300 underline';
        codeToggle.textContent = 'View Code';

        const codeContainer = document.createElement('div');
        codeContainer.className = 'hidden mt-2 bg-gray-900 rounded p-3 overflow-x-auto';

        const codeBlock = document.createElement('pre');
        codeBlock.className = 'text-xs text-green-400';
        codeBlock.textContent = data.code;
        codeContainer.appendChild(codeBlock);

        codeToggle.onclick = () => {
            if (codeContainer.classList.contains('hidden')) {
                codeContainer.classList.remove('hidden');
                codeToggle.textContent = 'Hide Code';
            } else {
                codeContainer.classList.add('hidden');
                codeToggle.textContent = 'View Code';
            }
        };

        bubble.appendChild(codeToggle);
        bubble.appendChild(codeContainer);
    }

    msgDiv.appendChild(bubble);
    container.appendChild(msgDiv);

    // Scroll to bottom
    container.scrollTop = container.scrollHeight;
}

function createChartElement(chartData) {
    const container = document.createElement('div');
    container.className = 'mt-3';

    if (chartData.title) {
        const title = document.createElement('h4');
        title.className = 'text-sm font-bold mb-2 text-gray-300';
        title.textContent = chartData.title;
        container.appendChild(title);
    }

    const canvasContainer = document.createElement('div');
    canvasContainer.className = 'relative h-64 bg-gray-900/50 rounded p-2';

    const canvas = document.createElement('canvas');
    canvasContainer.appendChild(canvas);
    container.appendChild(canvasContainer);

    // Render chart after a brief delay to ensure DOM is ready
    setTimeout(() => {
        if (chatChart) chatChart.destroy();

        const ctx = canvas.getContext('2d');
        chatChart = new Chart(ctx, {
            type: chartData.chartType || 'bar',
            data: chartData.data,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                ...chartData.options
            }
        });
    }, 100);

    return container;
}

function createTableElement(tableData) {
    const container = document.createElement('div');
    container.className = 'mt-3 overflow-x-auto';

    // Handle array of objects format (from pandas to_dict('records'))
    if (Array.isArray(tableData) && tableData.length > 0) {
        const table = document.createElement('table');
        table.className = 'w-full text-sm border-collapse';

        // Create headers from first object's keys
        const thead = document.createElement('thead');
        const headerRow = document.createElement('tr');
        headerRow.className = 'border-b border-gray-700';

        const headers = Object.keys(tableData[0]);
        headers.forEach(header => {
            const th = document.createElement('th');
            th.className = 'text-left py-2 px-3 text-gray-400 font-semibold';
            th.textContent = header;
            headerRow.appendChild(th);
        });

        thead.appendChild(headerRow);
        table.appendChild(thead);

        // Create rows
        const tbody = document.createElement('tbody');
        tableData.forEach((row, idx) => {
            const tr = document.createElement('tr');
            tr.className = 'border-b border-gray-800 hover:bg-gray-700/30';

            headers.forEach(header => {
                const td = document.createElement('td');
                td.className = 'py-2 px-3';
                td.textContent = row[header];
                tr.appendChild(td);
            });

            tbody.appendChild(tr);
        });

        table.appendChild(tbody);
        container.appendChild(table);
        return container;
    }

    // Legacy format support
    if (tableData.title) {
        const title = document.createElement('h4');
        title.className = 'text-sm font-bold mb-2 text-gray-300';
        title.textContent = tableData.title;
        container.appendChild(title);
    }

    const table = document.createElement('table');
    table.className = 'w-full text-sm border-collapse';

    // Headers
    if (tableData.headers) {
        const thead = document.createElement('thead');
        const headerRow = document.createElement('tr');
        headerRow.className = 'border-b border-gray-700';

        tableData.headers.forEach(header => {
            const th = document.createElement('th');
            th.className = 'text-left py-2 px-3 text-gray-400';
            th.textContent = header;
            headerRow.appendChild(th);
        });

        thead.appendChild(headerRow);
        table.appendChild(thead);
    }

    // Rows
    if (tableData.rows) {
        const tbody = document.createElement('tbody');

        tableData.rows.forEach((row, idx) => {
            const tr = document.createElement('tr');
            tr.className = 'border-b border-gray-800 hover:bg-gray-700/30';

            row.forEach(cell => {
                const td = document.createElement('td');
                td.className = 'py-2 px-3';
                td.textContent = cell;
                tr.appendChild(td);
            });

            tbody.appendChild(tr);
        });

        table.appendChild(tbody);
    }

    container.appendChild(table);
    return container;
}

function createCodeSection(code, result) {
    const container = document.createElement('div');
    container.className = 'mt-3';

    const header = document.createElement('div');
    header.className = 'flex items-center justify-between bg-gray-900 px-3 py-2 rounded-t cursor-pointer';
    header.innerHTML = `
        <span class="text-xs text-gray-400">Code</span>
        <span class="text-xs text-gray-500">▼</span>
    `;

    const codeBlock = document.createElement('pre');
    codeBlock.className = 'bg-gray-950 p-3 rounded-b text-xs overflow-x-auto';
    codeBlock.style.display = 'none';

    const codeElement = document.createElement('code');
    codeElement.className = 'text-green-400';
    codeElement.textContent = code;
    codeBlock.appendChild(codeElement);

    // Toggle code visibility
    header.onclick = () => {
        codeBlock.style.display = codeBlock.style.display === 'none' ? 'block' : 'none';
        header.querySelector('span:last-child').textContent = codeBlock.style.display === 'none' ? '▼' : '▲';
    };

    container.appendChild(header);
    container.appendChild(codeBlock);

    if (result) {
        const resultDiv = document.createElement('div');
        resultDiv.className = 'mt-2 p-2 bg-gray-900/50 rounded text-sm';
        resultDiv.textContent = `Result: ${result}`;
        container.appendChild(resultDiv);
    }

    return container;
}

// --- Waivers Logic ---

let sortCol = null;
let sortAsc = false;

async function loadWaivers() {
    // Update week display
    document.querySelector('.waiver-week-display').textContent = currentWeekSpec;

    // Check if already loaded
    if (waiversData.length > 0) {
        renderWaivers();
        return;
    }

    const tbody = document.getElementById('waivers-table-body');
    tbody.innerHTML = '<tr><td colspan="13" class="py-8 text-center text-gray-500 animate-pulse">Scouting free agents...</td></tr>';

    try {
        const response = await fetch('/api/waivers');
        const data = await response.json();

        if (!data || data.length === 0) {
            tbody.innerHTML = '<tr><td colspan="13" class="py-8 text-center text-gray-500">No players found on waivers.</td></tr>';
            return;
        }

        waiversData = data;

        // Initial sort
        sortWaivers('fpts');

    } catch (e) {
        console.error("Failed to load waivers:", e);
        tbody.innerHTML = '<tr><td colspan="13" class="py-8 text-center text-red-400">Error loading waiver wire.</td></tr>';
    }
}

function renderWaivers() {
    const tbody = document.getElementById('waivers-table-body');
    const displayData = waiversData.slice(0, 100); // Limit to top 100 for performance

    // Add Rank
    displayData.forEach((p, i) => p.rank = i + 1);

    // Stats config matching backend numeric_cols order (excluding minutes, fpts)
    // ['g', 'kp', 'at', 'sot', 'tkw', 'dis', 'yc', 'rc', 'acnc', 'int', 'clr', 'cos', 'bs', 'aer', 'pkm', 'pkd', 'og', 'gao', 'cs', 'ga', 'sv', 'pks', 'hcs', 'sm']
    const statsConfig = [
        { key: 'g', label: 'Goals' },
        { key: 'kp', label: 'Key Passes' },
        { key: 'at', label: 'Assists' },
        { key: 'sot', label: 'SoT' },
        { key: 'tkw', label: 'Tackles Won' },
        { key: 'dis', label: 'Dispossessed' },
        { key: 'yc', label: 'Yellow Cards' },
        { key: 'rc', label: 'Red Cards' },
        { key: 'acnc', label: 'Accurate Crosses' },
        { key: 'int', label: 'Interceptions' },
        { key: 'clr', label: 'Clearances' },
        { key: 'cos', label: 'Clean Sheets (D)' },
        { key: 'bs', label: 'Blocked Shots' },
        { key: 'aer', label: 'Aerials Won' },
        { key: 'pkm', label: 'PK Missed' },
        { key: 'pkd', label: 'PK Drawn' },
        { key: 'og', label: 'Own Goals' },
        { key: 'gao', label: 'Goal Errors' },
        { key: 'cs', label: 'Clean Sheets (G)' },
        { key: 'ga', label: 'Goals Against' },
        { key: 'sv', label: 'Saves' },
        { key: 'pks', label: 'PK Saves' },
        { key: 'hcs', label: 'High Claims' },
        { key: 'sm', label: 'Smothers' }
    ];

    // Inject subheaders if not already done
    const subHeaderRow = document.getElementById('waivers-subheaders-placeholder');
    if (subHeaderRow) {
        // Create the subheaders: 3 for each stat
        const subHeadersHTML = statsConfig.map(stat => `
            <th class="py-1 px-1 text-right font-medium text-[9px] text-gray-500 border-l border-gray-800/50 uppercase tracking-wider bg-gray-900 border-b border-gray-700 whitespace-nowrap min-w-[30px]" onclick="sortWaivers('${stat.key}')">Tot</th>
            <th class="py-1 px-1 text-right font-medium text-[9px] text-gray-500 uppercase tracking-wider bg-gray-900 border-b border-gray-700 whitespace-nowrap min-w-[30px]" onclick="sortWaivers('${stat.key}_per_game')">/G</th>
            <th class="py-1 px-1 text-right font-medium text-[9px] text-gray-500 border-r border-gray-800 uppercase tracking-wider bg-gray-900 border-b border-gray-700 whitespace-nowrap min-w-[30px]" onclick="sortWaivers('${stat.key}_per_90')">/90</th>
         `).join('');

        // Replace the placeholder with the actual cells
        subHeaderRow.outerHTML = subHeadersHTML;
    }

    tbody.innerHTML = displayData.map(p => {
        // Generate stats cells dynamically
        const statCells = statsConfig.map(stat => {
            const valTotal = (p[stat.key] || 0);
            const valPerGame = (p[`${stat.key}_per_game`] || 0).toFixed(2);
            const valPer90 = (p[`${stat.key}_per_90`] || 0).toFixed(2);

            // Style zero values dimmer
            const style = valTotal !== 0 ? 'text-gray-300' : 'text-gray-700';

            return `
                <td class="py-1 px-1 text-right ${style} font-mono text-[10px] border-l border-gray-800/50 whitespace-nowrap">${valTotal}</td>
                <td class="py-1 px-1 text-right ${style} font-mono text-[10px] whitespace-nowrap">${valPerGame}</td>
                <td class="py-1 px-1 text-right ${style} font-mono text-[10px] border-r border-gray-800 whitespace-nowrap">${valPer90}</td>
            `;
        }).join('');

        return `
        <tr class="hover:bg-gray-800/50 transition-colors border-b border-gray-800 last:border-0 group h-[30px]">
            <td class="py-1 px-1 sticky left-0 bg-gray-900 group-hover:bg-gray-800 transition-colors border-r border-gray-800 text-gray-400 font-mono text-center z-20 text-[10px]">${p.rank}</td>
            <td class="py-1 px-1 sticky left-[30px] bg-gray-900 group-hover:bg-gray-800 transition-colors border-r border-gray-800 font-medium text-white shadow-[2px_0_5px_rgba(0,0,0,0.5)] z-20 text-[10px] max-w-[120px] truncate" title="${p.player_name}">
                ${p.player_name}
            </td>
            <td class="py-1 px-1 text-center font-bold text-[10px] border-r border-gray-800 whitespace-nowrap uppercase">
                ${(p.injured && p.injured !== 'Available') ?
                `<span class="${p.injured === 'Out' ? 'text-red-500' : 'text-orange-400'}">${p.injured}</span>` :
                '<span class="text-green-500/30">OK</span>'}
            </td>
            <td class="py-1 px-1 text-center text-gray-400 text-[10px] uppercase whitespace-nowrap">${p.team || '-'}</td>
            <td class="py-1 px-1 text-center font-bold text-[10px] bg-gray-800 rounded px-1 w-min whitespace-nowrap mx-auto">${p.position}</td>
            
            <td class="py-1 px-1 text-right font-bold text-blue-400 font-mono text-[11px] border-l border-gray-700 whitespace-nowrap">${(p.fpts || 0).toFixed(1)}</td>
            <td class="py-1 px-1 text-right text-gray-300 font-mono text-[11px] whitespace-nowrap">${(p.fpts_per_game || 0).toFixed(1)}</td>
            <td class="py-1 px-1 text-right text-gray-300 font-mono text-[11px] border-r border-gray-700 bg-gray-800/20 whitespace-nowrap">${(p.fpts_per_90 || 0).toFixed(1)}</td>
            
            <td class="py-1 px-1 text-right text-gray-500 font-mono text-[10px] whitespace-nowrap">${p.minutes}</td>
            <td class="py-1 px-1 text-right text-gray-500 font-mono text-[10px] border-r border-gray-800 whitespace-nowrap">${p.gp}</td>
            
            ${statCells}
        </tr>
    `}).join('');
}

function sortWaivers(col) {
    if (sortCol === col) {
        sortAsc = !sortAsc;
    } else {
        sortCol = col;
        sortAsc = false; // Default to descending for stats

        // Exceptions for text columns
        if (['player_name', 'team', 'position'].includes(col)) sortAsc = true;
    }

    waiversData.sort((a, b) => {
        let valA = a[col];
        let valB = b[col];

        // Handle strings
        if (typeof valA === 'string') {
            valA = valA.toLowerCase();
            valB = valB.toLowerCase();
        } else {
            // Handle nulls/undefined as 0
            valA = valA || 0;
            valB = valB || 0;
        }

        if (valA < valB) return sortAsc ? -1 : 1;
        if (valA > valB) return sortAsc ? 1 : -1;
        return 0;
    });

    renderWaivers();
}
