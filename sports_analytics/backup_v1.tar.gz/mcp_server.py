
import os
import sys
import json
from typing import List, Dict, Any

# Ensure we can import config
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config

try:
    from mcp.server.fastmcp import FastMCP
    import praw
except ImportError as e:
    print(f"Error: Missing dependencies for MCP server. Please install 'mcp' and 'praw'.\nDetails: {e}", file=sys.stderr)
    sys.exit(1)

# Initialize MCP Server
mcp = FastMCP("Reddit Analytics Server")

# Initialize Reddit Client
def get_reddit():
    return praw.Reddit(
        client_id=config.REDDIT_CLIENT_ID,
        client_secret=config.REDDIT_CLIENT_SECRET,
        user_agent=config.REDDIT_USER_AGENT
    )

@mcp.tool()
def search_reddit_discussions(query: str, limit: int = 5, subreddits: List[str] = ["FantasyPL", "PremierLeague", "soccer"]) -> str:
    """
    Search Reddit for discussions about a player, team, or topic.
    Returns a formatted string of recent thread titles and top comments/summaries.
    
    Args:
        query: The search term (e.g. "Bukayo Saka", "Arsenal defence")
        limit: Number of threads to return (default 5)
        subreddits: List of subreddits to search (default ["FantasyPL", "PremierLeague", "soccer"])
    """
    try:
        reddit = get_reddit()
        
        # Combine subreddits for multi-sub search: "FantasyPL+PremierLeague"
        sub_query = "+".join(subreddits)
        print(f"Searching r/{sub_query} for '{query}'...", file=sys.stderr)
        
        results = []
        
        # Search specifically in these subreddits
        # sort='relevance' or 'new' might be better depending on goal. 
        # For "recent discussions", 'new' or 'relevance' with time_filter='month' is good.
        for submission in reddit.subreddit(sub_query).search(query, sort='relevance', time_filter='month', limit=limit):
            thread_data = f"### Thread: {submission.title}\n"
            thread_data += f"- **Subreddit**: r/{submission.subreddit.display_name}\n"
            thread_data += f"- **Score**: {submission.score} | **Comments**: {submission.num_comments}\n"
            thread_data += f"- **URL**: https://reddit.com{submission.permalink}\n"
            
            # Get top comment (simplified sentiment)
            submission.comments.replace_more(limit=0)
            if len(submission.comments) > 0:
                top_comment = submission.comments[0]
                thread_data += f"- **Top Comment**: \"{top_comment.body[:300]}...\"\n"
            
            results.append(thread_data)
            
        if not results:
            return f"No recent Reddit discussions found for '{query}' in r/{sub_query}."
            
        return "\n".join(results)
        
    except Exception as e:
        return f"Error searching Reddit: {str(e)}"

if __name__ == "__main__":
    try:
        mcp.run()
    except Exception as e:
        print(f"MCP Server Error: {e}", file=sys.stderr)
        sys.exit(1)
